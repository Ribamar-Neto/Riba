from lib import interface, opções, arquivo
from time import sleep

arq = 'cursoemvideo.txt'
if not arquivo.arquivoExiste(arq):
    arquivo.criarArquivo(arq)

while True:
    interface.cabeçalho('MENU PRINCIPAL')
    interface.menu(['Ver pessoas cadastradas', 'Cadastrar pessoa', 
                    'Apagar um cadastro', 'Limpar cadastros', 'Sair do sistema'])
    sleep(1)
    opcao = opções.leiaopcao() 
    opções.opcoes(opcao, arq)
    sleep(1)
    if opcao == 5:
        break
    