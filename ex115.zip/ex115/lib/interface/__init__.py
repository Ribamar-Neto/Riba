def colorprint(txt, color):
    print(f'{color}{txt}\033[m')


def linha():
    print('-'*42)            


def cabeçalho(txt):
    linha()
    print(txt.center(42))
    linha()


def menu(lista):
    print('\033[36m', end='')
    for i, v in enumerate(lista):
        print(i+1, '-', v)
    print('\033[m', end='')
    linha()
    
    
def centralizado(txt):
    print(f'{txt:^42}')
    