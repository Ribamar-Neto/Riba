def arquivoExiste(nome):
    try:
        a = open(nome, 'rt')
        a.close()
    except FileNotFoundError:
        return False
    else:
        return True
    
    
def criarArquivo(nome):
    from lib import interface
    try:
        a = open(nome, 'wt+')
        a.close()
    except:
        interface.colorprint('Houve um erro na criação do arquivo.', '\033[31m')
    else:
        interface.colorprint(f'Arquivo {nome} criado com sucesso!', '\033[32m')
        
        
def lerArquivo(nome):
    from lib import interface
    try:
        a = open(nome, 'rt')
    except:
        interface.colorprint('Erro ao ler o arquivo!', '\033[31m')
    else:
        interface.centralizado('Pessoas cadastradas'.upper())
        for linha in a:
            dado = linha.split(';')
            dado[1] = dado[1].replace('\n', '')
            print(f'{dado[0]:<30}\t{dado[1]:>3} anos')
    finally:
        a.close()
        
        
def cadastrar(arq, nome='<desconhecido>', idade=0):
    from lib import interface
    try:
        a = open(arq, 'at')
    except:
        interface.colorprint('Houve um ERRO na abertura do arquivo!', '\033[31m')
    else:
        try:
            a.write(f'{nome};{idade}\n')
        except:
            interface.colorprint('Houve um ERRO na hora de escrever os dados!', '\033[31m')
        else:
            interface.colorprint(f'Novo registro de {nome} adicionado.', '\033[32m')
            a.close()
            

def apagarLinha(txt):
    from lib import interface
    with open(txt, 'r') as a:
        dados = a.readlines()
        numlinha = 1
        linhadel = int(input("Digite o número da linha a ser deletada: "))
        with open(txt, 'w') as a:
          for linha in dados:
            if numlinha != linhadel:
                a.write(linha)
                numlinha += 1
            else:
                break
    interface.colorprint(f'Linha {linhadel} foi deletada com sucesso!', '\033[32m')


def limparArquivo(txt):
    from lib import interface
    with open(txt, 'w') as a:
        a.write('')
        a.close()
        interface.colorprint('Registros removidos com sucesso!', '\033[32m')
    