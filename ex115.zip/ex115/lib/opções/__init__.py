def leiaopcao():
    from time import sleep
    while True:
        try:
            opcao = int(input('\033[32mSua opção: \033[m'))
        except (ValueError, TypeError):
            print('\033[31mERRO! Digite um número inteiro entre 1 e 5.\033[m')
            sleep(1.2)
        else:
            if opcao > 5 or opcao < 1:
                print('\033[31mERRO! Digite apenas 1, 2, 3, 4 ou 5.\033[m')
                sleep(1.2)
            else:
                return opcao
            
            
def leiaInt(txt):
    while True:
        try:
            num = int(input(txt))
        except(ValueError, TypeError):
            print('\033[31mERRO! Digite um número inteiro.\033[m')
        else:
            return num

            
def opcoes(opcao, txt):
    from lib import interface, arquivo
    
    if opcao != 5:
        interface.cabeçalho(f'Opção {opcao}')
        if opcao == 1:
            arquivo.lerArquivo(txt)   
        elif opcao == 2:
            interface.centralizado('Novo cadastro'.upper()) 
            nome = str(input('Nome: '))
            idade = leiaInt('Idade: ')
            arquivo.cadastrar(txt, nome, idade)
        elif opcao == 3:
            arquivo.apagarLinha(txt)
        elif opcao == 4:
            arquivo.limparArquivo(txt)
    else:
        interface.cabeçalho('Saindo do sistema... até logo!')
